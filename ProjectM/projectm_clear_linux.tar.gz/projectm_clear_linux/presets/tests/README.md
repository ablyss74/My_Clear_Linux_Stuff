These presets are designed to test very specific functionality to help with regression testing when code changes are made.
